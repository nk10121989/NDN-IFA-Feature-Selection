
data2=csvread("PIT94x.csv");
data4=csvread("PIT98x.csv");
data8=csvread("PIT916x.csv");
data=[];
for i=1:5
    data(:,i,1)=data2(:,i);
    data(:,i,2)=data4(:,i);
    data(:,i,3)=data8(:,i);
end

    plot(data(:,1,1),data(:,5,1));
    hold on;
    plot(data(:,1,1),data(:,5,2)); 
    hold on;
    plot(data(:,1,1),data(:,5,3));
    hold on;
    xlabel("Time in seconds");
    ylabel("Number of PIT entries for Router 9 Interface 5");
    pause;


legend=["Time in seconds","PITSize(R1)","PITSize(R2)","PITSize(R3)","PITSize(R4)","PITSize(R5)","PITSize(R6)","PITSize(R7)","PITSize(R8)","PITSize(R9)","PITSize(R10)","PITSize(R11)"];
for i=2:11
    plot(data(:,1,1),data(:,i,1));
    hold on;
    plot(data(:,1,1),data(:,i,2));
    hold on;
    plot(data(:,1,1),data(:,i,3));
    hold on;
    xlabel(legend(1));
    ylabel(legend(i));
    pause;
end

