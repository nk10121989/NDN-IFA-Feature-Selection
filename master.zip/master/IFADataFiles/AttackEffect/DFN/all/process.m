
data2=csvread("data4x.csv");
data4=csvread("data8x.csv");
data8=csvread("data16x.csv");
data=[];
for i=1:16
    data(:,i,1)=data2(:,i);
    data(:,i,2)=data4(:,i);
    data(:,i,3)=data8(:,i);
end
legend=["Time in seconds","DropData","OutInterests","DropInterests","InData","InTimedOutInterests","OutTimedOutInterests","DropNacks","InInterests","OutData","SatisfiedInterests","InNacks","OutNacks","TimedOutInterests","InSatisfiedInterests","OutSatisfiedInterests"];
for i=2:16
    fprintf(legend(i)+"\n");
    plot(data(:,1,1),data(:,i,1));
    hold on;
    plot(data(:,1,1),data(:,i,2));
    hold on;
    plot(data(:,1,1),data(:,i,3));
    hold on;
        xlabel(legend(1));
    ylabel(legend(i));
    pause;
end

