
data2=csvread("pit4x.csv");
data4=csvread("pit8x.csv");
data8=csvread("pit16x.csv");
data=[];
for i=1:8
    
    data(:,i,1)=data2(:,i);
    data(:,i,2)=data4(:,i);
    data(:,i,3)=data8(:,i);
end

plot(data(:,1,1),data(:,6,1));
hold on;
plot(data(:,1,1),data(:,8,2));
hold on;
xlabel("Time in seconds");
ylabel("PITSize");
pause;

legend=["Time in seconds","PITSize(R1)","PITSize(R2)","PITSize(R3)","PITSize(R4)","PITSize(R5)","PITSize(R6)","PITSize(R7)"];
for i=2:8
    plot(data(:,1,1),data(:,i,1));
    hold on;
    plot(data(:,1,1),data(:,i,2));
    hold on;
    
    plot(data(:,1,1),data(:,i,3));
    hold on;
    xlabel(legend(1));
    ylabel(legend(i));
    pause;
end

