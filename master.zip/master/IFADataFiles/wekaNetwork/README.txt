Open Weka
Open Knowledge Flow
Right Click File
Click Open
Browse classifier.kf
This network is used for the classification
To know the working go to : https://www.cs.waikato.ac.nz/~ml/weka/